A Pen created at CodePen.io. You can find this one at https://codepen.io/terone71/pen/KBveVy.

 A concept for a chat interface. Try writing a new message! :)